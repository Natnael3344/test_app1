package com.example.shalom

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
